// Optional: content script can extract page text and send to popup if needed
// For now we just leave it lightweight
console.log("[AuthentiScan] Content script loaded.");