// Service worker (MV3) – minimal for now
chrome.runtime.onInstalled.addListener(() => {
  console.log("[AuthentiScan] Extension installed.");
});